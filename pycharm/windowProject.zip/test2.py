import wx

# 로그인
class LoginForm(wx.Frame):
    def __init__(self, title=None, size=None):
        super().__init__(None, title=title, size=size)
        self.ui()

    def ui(self):
        self.panel= wx.Panel(self)

        wx.StaticText(self.panel, label='ID: ', pos=(5,5))
        wx.StaticText(self.panel, label='Pass: ', pos=(5,40))
        self.m_id= wx.TextCtrl(self.panel, pos= (50,5), size=(200,-1))
        self.m_pw= wx.TextCtrl(self.panel, pos= (50,40), size=(200,-1))

        btn1= wx.Button(self.panel, pos=(5,100), label='로그인')
        btn2= wx.Button(self.panel, pos=(90,100), label='종료')

        btn1.Bind(wx.EVT_BUTTON, self.onBtHandler1)
        btn2.Bind(wx.EVT_BUTTON, self.onBtHandler2)

    def onBtHandler1(self, e):
        print('버튼이 눌렸다')

    def onBtHandler2(self, e):
        self.Close(True)

if __name__=='__main__':
    app= wx.App() # 윈도우 프로그래밍 메모리 생성
    LoginForm(title='로그인', size=(300,200)).Show(True) # parent 윈도우가 없음
    app.MainLoop() # 계속 실행